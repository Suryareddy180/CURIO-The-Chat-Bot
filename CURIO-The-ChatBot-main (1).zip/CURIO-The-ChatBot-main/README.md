# CURIO-The-ChatBot
**CURIO** is your smart AI companion, blending sleek design with powerful intelligence. Powered by Django and Google Gemini API, CURIO answers your questions with precision and personality. With its friendly vibe, custom greetings, and smooth interface, CURIO isn't just a chatbot—it's your go-to guide for curiosity, knowledge, and fun. 
